import{C as r}from"./index.9d56859b.js";function n(n,o){return r(n)?o:n}export{n as r};
