var s="/assets/logo.f85c9a23.jpg",a="/assets/icon2_weixin.78f29282.png",c="/assets/icon2_wb.288e0c74.png",e="/assets/icon2_QQ.959d621c.png";export{s as _,a,c as b,e as c};
